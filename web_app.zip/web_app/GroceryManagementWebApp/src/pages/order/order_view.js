

define([
  "jquery",
  "underscore",
  "backbone",
  "handlebars",
  "JST",
  "HelperUtils",
  ], function($, _, Backbone, Handlebars,JST,HelperUtils){

    var OrderView = Backbone.View.extend({el: $("#page"),
      template: JST.order_template,

      initialize: function () {
        this.render();
      },

      events: {
       "click  #orderSubmit" : "saveOrder",
     },
     render: function () {
      this.$el.html(this.template(this.model.attributes));
    },

    saveOrder: function(e) {      
      e.preventDefault();
      this.model.set(HelperUtils.getFormData(this.$el.find('form')));
      this.model.save({ 
       success : function (data) {
         console.log(data);
       }
     });
    },
  });

    return OrderView;
  });