
define([
	"jquery", 
	"backbone"  
	], function($, Backbone){
	   var BillModel = Backbone.Model.extend({	
	   
	  	urlRoot: 'http://localhost:8080/bill',
			idAttribute: '_id',
});
	return BillModel;
});