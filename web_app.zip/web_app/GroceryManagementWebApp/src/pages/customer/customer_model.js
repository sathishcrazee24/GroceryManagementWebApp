
define([
	"jquery", 
	"backbone"  
	], function($, Backbone){
	   var CustomerModel = Backbone.Model.extend({	
	   
	  	urlRoot: 'http://localhost:8080/customers',
			idAttribute: '_id',
});
	return CustomerModel;
});