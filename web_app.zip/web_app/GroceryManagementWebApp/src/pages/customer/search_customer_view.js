

define([
  "jquery",
  "underscore",
  "backbone",
  "handlebars",
  "JST",
  "HelperUtils",
  ], function($, _, Backbone, Handlebars,JST,HelperUtils){

    var SearchCustomerView = Backbone.View.extend({el: $("#page"),
      template: JST.search_customer_template,

      initialize: function () {
        this.render();
      },

      events: {
       /*"click  #customerSubmit" : "searchCustomer",*/
     },
     render: function () {
      this.$el.html(this.template(this.model.attributes));
      this.onShow();

    },
    onShow:function(){
     $("#jsGrid").jsGrid({
        /*height: "100%",*/
        width: "100%",
        filtering: true,
        editing: true,
        sorting: true,
        paging: true,
        autoload: true,
        pageSize: 15,
        pageButtonCount: 5,
        controller: db,
        fields: [
        { name: "Name", type: "text", width: 150 },
        { name: "Age", type: "number", width: 50 },
        { name: "Address", type: "text", width: 200 },
        { name: "Country", type: "select", items: db.countries, valueField: "Id", textField: "Name" },
        { name: "Married", type: "checkbox", title: "Is Married", sorting: false },
        { type: "control", modeSwitchButton: false, editButton: false }
        ]
      });

     /* $("#jsGrid").jsGrid({
        width: "100%",
        height: "auto",

        autoload:   true,
        paging:     true,
        pageSize:   5,
        pageButtonCount: 5,
        pageIndex:  1,

        controller: {
          loadData: function(filter) {
            return $.ajax({
              url: "http://localhost:8080/customers",
              dataType: "json"
            });
          }
        },
        fields: [
        {name: "customer_name", width: 50},
        {name: "primary_phno", width: 100},
        {name: "secondary_phno", width: 50},
        {name: "landline_no", width: 50},
        {name: "emailaddress", width: 50},
        {name: "address", width: 50},
        {name: "gstn_no", width: 50},
        {name: "tin_no", width: 50},
        {name: "nickName1", width: 50},
        {name: "nickName2", width: 50}
        ]
      });*/

      $(".config-panel input[type=checkbox]").on("click", function() {
        var $cb = $(this);
        $("#jsGrid").jsGrid("option", $cb.attr("id"), $cb.is(":checked"));
      });


    },

    searchCustomer: function(e) {      
     /* e.preventDefault();
      this.model.set(HelperUtils.getFormData(this.$el.find('form')));
      this.model.save({ 
       success : function (data) {
         console.log(data);
       }
     });*/
   },
 });

    return SearchCustomerView;
  });