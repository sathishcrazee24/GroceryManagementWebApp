


public class Company {
	 private static final long serialVersionUID = 1L;
	
	 private String company_name="SRI BALAGANAPTHY TRADERS";
	 private String mobile_phno="9486529374";  
	 private String landline_phno="04171221370";     
     private String address="15,Dhaadi arunachalam street";
     private String town="Gudiyatham";
     private String district="Vellore district";
     private String pincode="632602";
     private String gstn_no="33AEHPR8048C1ZI";
     private String tin_no="33AEHPR8048C1ZI";
     private String account_number="10996053895";
     private String ifsc_code="SBIN000842";
     
	public String getCompany_name() {
		return company_name;
	}
	public void setCompany_name(String company_name) {
		this.company_name = company_name;
	}
	public String getMobile_phno() {
		return mobile_phno;
	}
	public void setMobile_phno(String mobile_phno) {
		this.mobile_phno = mobile_phno;
	}
	public String getLandline_phno() {
		return landline_phno;
	}
	public void setLandline_phno(String landline_phno) {
		this.landline_phno = landline_phno;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getGstn_no() {
		return gstn_no;
	}
	public void setGstn_no(String gstn_no) {
		this.gstn_no = gstn_no;
	}
	public String getTin_no() {
		return tin_no;
	}
	public void setTin_no(String tin_no) {
		this.tin_no = tin_no;
	}
	public String getAccount_number() {
		return account_number;
	}
	public void setAccount_number(String account_number) {
		this.account_number = account_number;
	}
	public String getIfsc_code() {
		return ifsc_code;
	}
	public void setIfsc_code(String ifsc_code) {
		this.ifsc_code = ifsc_code;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public String getDistrict() {
		return district;
	}
	public void setDistrict(String district) {
		this.district = district;
	}
	public String getPincode() {
		return pincode;
	}
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}
	public String getTown() {
		return town;
	}
	public void setTown(String town) {
		this.town = town;
	}
     
}