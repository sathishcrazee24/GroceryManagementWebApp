
import com.itextpdf.io.font.FontConstants;
import com.itextpdf.io.font.FontProgramFactory;
import com.itextpdf.kernel.font.PdfFont;
import com.itextpdf.kernel.font.PdfFontFactory;
import com.itextpdf.kernel.geom.Line;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.border.Border;
import com.itextpdf.layout.element.Cell;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;
import com.itextpdf.layout.element.Text;
import com.itextpdf.layout.property.TextAlignment;
import com.itextpdf.layout.property.UnitValue;
import com.itextpdf.layout.property.VerticalAlignment;

import java.io.File;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;


public class FirstPDF  {

	
		public static final String DEST = "C:\\Users\\SATHISH\\pdf_generated\\centered_text_in_cell.pdf";
	    
	    /** The path to the color profile. */
	    public static final String ICC = "C:/Users/SATHISH/workspace/pdfGenerator/src/main/resources/color/sRGB_CS_profile.icm";
	    
	    /** The path to a regular font. */
	    public static final String REGULAR = "C:/Users/SATHISH/workspace/pdfGenerator/src/main/resources/fonts/OpenSans-Regular.ttf";
	    
	    /** The path to a bold font. */
	    public static final String BOLD = "C:/Users/SATHISH/workspace/pdfGenerator/src/main/resources/fonts/OpenSans-Bold.ttf";
	    
	    /** A <code>String</code> with a newline character. */
	    public static final String NEWLINE = "\n";
	    
	    

	public static void main(String[] args) throws Exception {
		File file = new File(DEST);
		file.getParentFile().mkdirs();
		new FirstPDF().manipulatePdf(DEST);
	}

	private Cell prepareCompanyCell()throws Exception
	{ 
		PdfFont font = PdfFontFactory.createFont(FontProgramFactory.createFont(FontConstants.HELVETICA_BOLD));	
		Cell company_Cell = new Cell();
		//company_Cell.setHeight(50);
		company_Cell.setVerticalAlignment(VerticalAlignment.MIDDLE);
		/*company_Cell.add(new Paragraph("Test 2"));*/
		
		Company company =new Company();
		company_Cell.add(new Paragraph("Supplier details :"));
		company_Cell.add(new Paragraph(company.getCompany_name()));
		company_Cell.add(new Paragraph("Address :"));
		company_Cell.add(new Paragraph(company.getAddress()));		
		company_Cell.add(new Paragraph("GST Number : "+company.getGstn_no()));
		company_Cell.add(new Paragraph("Account Number : "+company.getAccount_number()));		
		company_Cell.add(new Paragraph("IFSC Code : "+company.getIfsc_code()));
		
		
		
		
		company_Cell.setFont(font);		
		return company_Cell;

	}

	private Cell prepareCustomerCell() throws Exception
	{
		PdfFont font = PdfFontFactory.createFont(FontProgramFactory.createFont(FontConstants.HELVETICA_BOLD));
		Paragraph para = new Paragraph("Test").setFont(font);
		para.setFixedLeading(0);
		para.setMultipliedLeading(1);
		Cell customer_Cell = new Cell();
		customer_Cell.setHeight(50);
		customer_Cell.setVerticalAlignment(VerticalAlignment.MIDDLE);
		customer_Cell.add(para);
		return customer_Cell;
	}


	protected void manipulatePdf(String dest) throws Exception {
		//REQUIRE A SIZE
		PdfDocument pdfDoc = new PdfDocument(new PdfWriter(dest));
		Document document = new Document(pdfDoc);


		/*Table heading_table = new Table(2);
		heading_table.addCell(prepareCompanyCell());
		heading_table.addCell(prepareCustomerCell());					
		Table order_table = new Table(2);
		order_table.addCell(prepareCompanyCell());
		order_table.addCell(prepareCustomerCell());
		doc.add(heading_table);
		doc.add(new Paragraph("           "));		
		doc.add(order_table);*/
		
		Order order = new Order();
		order.setOrder_date(new Date());
		order.setOrder_id(new Long("12121"));
		
		
		document.setFont(PdfFontFactory.createFont(REGULAR, true))
		.setFontSize(12);
PdfFont bold = PdfFontFactory.createFont(BOLD, true);
		 // Add the header
    	document.add(
    		new Paragraph()
			.	setTextAlignment(TextAlignment.RIGHT)
				.setMultipliedLeading(1)
    			.add(new Text(String.format("%s %s\n", "INVOICE",order.getOrder_id()))
    					.setFont(bold).setFontSize(14))
    			.add(convertDate(order.getOrder_date(), "MMM dd, yyyy")));
        // Add the seller and buyer address
        document.add(getAddressTable(new Company(), new Customer(), bold));
        // Add the line items
        //document.add(getLineItemTable(new OrderItems(), bold));
        // Add the grand totals
       /* document.add(getTotalsTable(
                basic.getTaxBasisTotalAmount(), basic.getTaxTotalAmount(), basic.getGrandTotalAmount(), basic.getGrandTotalAmountCurrencyID(),
                basic.getTaxTypeCode(), basic.getTaxApplicablePercent(),
                basic.getTaxBasisAmount(), basic.getTaxCalculatedAmount(), basic.getTaxCalculatedAmountCurrencyID(), bold));
        // Add the payment info
        document.add(getPaymentInfo(basic.getPaymentReference(), basic.getPaymentMeansPayeeFinancialInstitutionBIC(), basic.getPaymentMeansPayeeAccountIBAN()));
        */
        document.close();
        
        

        document.close();
	}
	  /**
     * Convert a date to a String in a certain format.
     *
     * @param d the date
     * @param newFormat the new format
     * @return the date as a string
     * @throws ParseException the parse exception
     */
    public String convertDate(Date d, String newFormat) throws ParseException {
        SimpleDateFormat sdf = new SimpleDateFormat(newFormat);
        return sdf.format(d);
    }
    
    /**
     * Gets the address table.
     *
     * @param basic the {@link IBasicProfile} instance
     * @param bold a bold font
     * @return the address table
     */
    public Table getAddressTable(Company basic,Customer customer, PdfFont bold) {
        Table table = new Table(new UnitValue[]{
        		new UnitValue(UnitValue.PERCENT, 50),
        		new UnitValue(UnitValue.PERCENT, 50)})
        		.setWidthPercent(100);
        table.addCell(getPartyAddress("Supplier details:",
                /*basic.getSellerName(),
                basic.getSellerLineOne(),
                basic.getSellerLineTwo(),
                basic.getSellerCountryID(),
                basic.getSellerPostcode(),
                basic.getSellerCityName(),
                bold));*/
        		
        		basic.getCompany_name(),
        basic.getAddress(),
        basic.getDistrict(),
        basic.getPincode(),
        new String("Mobile - "+basic.getMobile_phno()),
        new String("Landline - "+basic.getLandline_phno()),
/*        "Supplier GST-"+basic.getGstn_no(),*/
        bold));
		
        
        
        table.addCell(getPartyAddress("Customer details:",
                /*basic.getSellerName(),
                basic.getSellerLineOne(),
                basic.getSellerLineTwo(),
                basic.getSellerCountryID(),
                basic.getSellerPostcode(),
                basic.getSellerCityName(),
                bold));*/
        		
        		basic.getCompany_name(),
        basic.getAddress(),
        basic.getDistrict(),
        basic.getPincode(),
        new String("Mobile - "+basic.getMobile_phno()),
        new String("Landline - "+basic.getLandline_phno()),
        /*"Customer GST-"+basic.getGstn_no(),*/
        bold));
        
        
/*        table.addCell(getPartyAddress("To:",
                basic.getBuyerName(),
                basic.getBuyerLineOne(),
                basic.getBuyerLineTwo(),
                basic.getBuyerCountryID(),
                basic.getBuyerPostcode(),
                basic.getBuyerCityName(),
                bold));*/
        table.addCell(getPartyTax(new String[]{basic.getGstn_no(),basic.getGstn_no()},
        		new String[]{"GST NO","VAT NO"}, bold));
        
        table.addCell(getPartyTax(new String[]{basic.getGstn_no(),basic.getGstn_no()},
        		new String[]{"GST NO","VAT NO"}, bold));
        return table;
    }
    
    /**
     * Gets the party address.
     *
     * @param who either "To:" or "From:"
     * @param name the addressee
     * @param line1 line 1 of he address
     * @param line2 line 2 of the address
     * @param countryID the country ID
     * @param postcode the post code
     * @param city the city
     * @param bold a bold font
     * @return a formatted address cell
     */
    
    
    public Cell getPartyAddress(String who, String Company_name, String Address, String District, String postcode,
    		String Mobile_phno, String Landline_phno/*,String gst_no*/, PdfFont bold) {
    	Paragraph p = new Paragraph()
    			.setMultipliedLeading(1.0f)
        		.add(new Text(who).setFont(bold)).add(NEWLINE)
                .add(Company_name).add(NEWLINE)
                .add(Address).add(NEWLINE)
                .add(String.format("%s-%s", District, postcode)).add(NEWLINE)              
		    	.add(Mobile_phno).add(NEWLINE)
		    	.add(Landline_phno).add(NEWLINE);
        Cell cell = new Cell()        
        		.add(p)./*add(gst_no).*/add(NEWLINE)
        		.setBorder(Border.NO_BORDER);
        return cell;
    }
    
    /**
     * Gets the party tax.
     *
     * @param taxId the tax id
     * @param taxSchema the tax schema
     * @param bold a bold font
     * @return a formatted cell
     */
    public Cell getPartyTax(String[] taxId, String[] taxSchema, PdfFont bold) {
    	Paragraph p = new Paragraph()
    		.setFontSize(10).setMultipliedLeading(1.0f)
			.add(new Text("Tax ID(s):").setFont(bold));
        if (taxId.length == 0) {
            p.add("\nNot applicable");
        }
        else {
            int n = taxId.length;
            for (int i = 0; i < n; i++) {
                p.add(NEWLINE)
                .add(String.format("%s: %s", taxSchema[i], taxId[i]));
            }
        }
        return new Cell().setBorder(Border.NO_BORDER).add(p);
    }
    
    /**
     * Gets the line item table.
     *
     * @param invoice the invoice
     * @param bold a bold font
     * @return the line item table
     */
    public Table getLineItemTable(OrderItems orderitems,/*Invoice invoice,*/ PdfFont bold) {
        Table table = new Table(new UnitValue[]{
        		new UnitValue(UnitValue.PERCENT, 43.75f),
        		new UnitValue(UnitValue.PERCENT, 12.5f),
        		new UnitValue(UnitValue.PERCENT, 6.25f),
        		new UnitValue(UnitValue.PERCENT, 12.5f),
        		new UnitValue(UnitValue.PERCENT, 12.5f),
        		new UnitValue(UnitValue.PERCENT, 12.5f)})
        		.setWidthPercent(100)
				.setMarginTop(10).setMarginBottom(10);
        table.addHeaderCell(createCell("Item:", bold));
        table.addHeaderCell(createCell("Price:", bold));
        table.addHeaderCell(createCell("Qty:", bold));
        table.addHeaderCell(createCell("Subtotal:", bold));
        table.addHeaderCell(createCell("VAT:", bold));
        table.addHeaderCell(createCell("Total:", bold));
        /*Product product;
        for (Item item : invoice.getItems()) {
            product = item.getProduct();
            table.addCell(createCell(product.getName()));
            table.addCell(createCell(
            	InvoiceData.format2dec(InvoiceData.round(product.getPrice())))
                .setTextAlignment(TextAlignment.RIGHT));
            table.addCell(createCell(String.valueOf(item.getQuantity()))
                .setTextAlignment(TextAlignment.RIGHT));
            table.addCell(createCell(
                InvoiceData.format2dec(InvoiceData.round(item.getCost())))
                .setTextAlignment(TextAlignment.RIGHT));
            table.addCell(createCell(
                InvoiceData.format2dec(InvoiceData.round(product.getVat())))
                .setTextAlignment(TextAlignment.RIGHT));
            table.addCell(createCell(
                InvoiceData.format2dec(InvoiceData.round(
                	item.getCost() + ((item.getCost() * product.getVat()) / 100))))
                .setTextAlignment(TextAlignment.RIGHT));
        }*/
        return table;
    }
    
    /**
     * Creates a cell with specific properties set.
     *
     * @param text the text that will be in the cell
     * @return the cell
     */
    
    public Cell createCell(String text) {
    	return new Cell().setPadding(0.8f)
    		.add(new Paragraph(text)
    			.setMultipliedLeading(1));
    }
    
    /**
     * Creates a cell with specific properties set.
     *
     * @param text the text that will be in the cell
     * @param font the font
     * @return the cell
     */
    public Cell createCell(String text, PdfFont font) {
    	return new Cell().setPadding(0.8f)
        	.add(new Paragraph(text)
        		.setFont(font).setMultipliedLeading(1));
    }
    
    /**
     * Gets the totals table.
     *
     * @param tBase the total tax base
     * @param tTax the total tax amount
     * @param tTotal the total tax
     * @param tCurrency the tax currency
     * @param type the tax types
     * @param percentage the tax percentages
     * @param base the base amounts
     * @param tax the tax amounts
     * @param currency the currencies
     * @param bold a bold font
     * @return the totals table
     */
    public Table getTotalsTable(String tBase, String tTax, String tTotal, String tCurrency,
            String[] type, String[] percentage, String base[], String tax[], String currency[],
            PdfFont bold) {
        Table table = new Table(new UnitValue[]{
        		new UnitValue(UnitValue.PERCENT, 8.33f),
        		new UnitValue(UnitValue.PERCENT, 8.33f),
        		new UnitValue(UnitValue.PERCENT, 25f),
        		new UnitValue(UnitValue.PERCENT, 25f),
        		new UnitValue(UnitValue.PERCENT, 25f),
        		new UnitValue(UnitValue.PERCENT, 8.34f)})
        	.setWidthPercent(100);
        table.addCell(createCell("TAX:", bold));
        table.addCell(createCell("%", bold)
        	.setTextAlignment(TextAlignment.RIGHT));
        table.addCell(createCell("Base amount:", bold));
        table.addCell(createCell("Tax amount:", bold));
        table.addCell(createCell("Total:", bold));
        table.addCell(createCell("Curr.:", bold));
        int n = type.length;
        for (int i = 0; i < n; i++) {
            table.addCell(createCell(type[i])
            	.setTextAlignment(TextAlignment.RIGHT));
            table.addCell(createCell(percentage[i])
            	.setTextAlignment(TextAlignment.RIGHT));
            table.addCell(createCell(base[i])
            	.setTextAlignment(TextAlignment.RIGHT));
            table.addCell(createCell(tax[i])
            	.setTextAlignment(TextAlignment.RIGHT));
            double total = Double.parseDouble(base[i]) + Double.parseDouble(tax[i]);
            /*table.addCell(createCell(
            	InvoiceData.format2dec(InvoiceData.round(total)))
            	.setTextAlignment(TextAlignment.RIGHT));*/
            table.addCell(createCell(currency[i]));
        }
        table.addCell(new Cell(1, 2).setBorder(Border.NO_BORDER));
        table.addCell(createCell(tBase, bold)
        	.setTextAlignment(TextAlignment.RIGHT));
        table.addCell(createCell(tTax, bold)
        	.setTextAlignment(TextAlignment.RIGHT));
        table.addCell(createCell(tTotal, bold)
        	.setTextAlignment(TextAlignment.RIGHT));
        table.addCell(createCell(tCurrency, bold));
        return table;
    }
    
    /**
     * Gets the payment info.
     *
     * @param ref the reference
     * @param bic the BIC code
     * @param iban the IBAN code
     * @return the payment info
     */
    public Paragraph getPaymentInfo(String ref, String[] bic, String[] iban) {
        Paragraph p = new Paragraph(String.format(
                "Please wire the amount due to our bank account using the following reference: %s",
                ref));
        int n = bic.length;
        for (int i = 0; i < n; i++) {
            p.add(NEWLINE).add(String.format("BIC: %s - IBAN: %s", bic[i], iban[i]));
        }
        return p;
    }
}
