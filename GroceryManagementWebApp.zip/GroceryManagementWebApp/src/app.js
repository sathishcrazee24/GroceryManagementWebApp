

define([
  'jquery', 
  'underscore', 
  'backbone',
  'AppRouter', // Request router.js
], function($, _, Backbone, Router){
  var initialize = function(){
   /* //cors disable
    $.ajaxPrefilter(function(options, originalOptions, jqXHR) {
        options.crossDomain ={
            crossDomain: true
        };
        options.xhrFields = {
            withCredentials: true
        };
    });*/
    // Pass in our Router module and call it's initialize function
    Router.initialize();
  };
  return { 
    initialize: initialize
  };
});



