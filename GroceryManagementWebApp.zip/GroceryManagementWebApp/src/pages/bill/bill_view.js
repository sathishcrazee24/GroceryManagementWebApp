

define([
  "jquery",
  "underscore",
  "backbone",
  "handlebars",
  "JST"
  ], function($, _, Backbone, Handlebars,JST){

    var BillView = Backbone.View.extend({



 
     el: $("#page"),

     template: JST.bill_template,

      initialize: function () {
          this.render();
      },

     events: {
           "click  #billSubmit" : "saveBill",
      },

      render: function () {          
          this.$el.html(this.template(this.model.attributes));
      },



      saveBill :function () {

         this.model.set("item_name","item_name");
        this.model.set("category","category");        
       this.model.save();
      }
 });

    return BillView;
  });