
define([
	"jquery", 
	"backbone"  
	], function($, Backbone){
	   var BillModel = Backbone.Model.extend({	
	   
	  	url: '/bill',

	  	defaults : {
	  	item_name : "SVN",
	  	category : "OIL",
	  	},
});
	return BillModel;
});