define([
  "jquery",
  "underscore",
  "backbone",
  "handlebars",
  "JST",
  "HelperUtils",
  ], function($, _, Backbone, Handlebars,JST,HelperUtils){

    var SearchCustomerView = Backbone.View.extend({el: $("#page"),
      template: JST.search_customer_template,

      initialize: function () {
        this.render();
      },

      events: {
        "click  .customGridDuplicatebutton" : "duplicate",
        /*"click  #customerSubmit" : "searchCustomer",*/
      },
      render: function () {
        this.$el.html(this.template(this.model.attributes));
        this.onShow();

      },

      duplicate :function (Id) {
       newId = null;
      myData = $("#jsGrid").getLocalRow(Id);//or getRowData(Id)
      $("#jsGrid").jqGrid('addRowData', newId, myData, "after", Id);
      db.customers.push(myData);//incomplte change customer id to null beofre duplcate
    },



    onShow:function(){

      $(".config-panel input[type=checkbox]").on("click", function() {
        var $cb = $(this);
        $("#jsGrid").jsGrid("option", $cb.attr("id"), $cb.is(":checked"));
      });

      var self=this;

      $("#jsGrid").jsGrid({
        /*height: "100%",*/
        width: "100%",
        filtering: true,
        editing: true,
        sorting: true,
        paging: true,
        autoload: true,
        pageSize: 15,
        pageButtonCount: 5,
        deleteConfirm: "Do you really want to delete the customer?",
        controller: {
          loadData: function(filter) {
            if(db === undefined || (db != undefined && db.customers === undefined))
            {
              return [];
            }
            else
            {
              return $.grep(db.customers, function(client) {
                return  (!filter.customer_name || client.customer_name.indexOf(filter.customer_name) > -1) &&
                (filter.primary_phno === undefined || client.primary_phno === filter.primary_phno) &&
                (filter.secondary_phno === undefined || client.secondary_phno === filter.secondary_phno) &&
                (filter.landline_no === undefined || client.landline_no === filter.landline_no) &&               
                (!filter.emailaddress || client.emailaddress.indexOf(filter.emailaddress) > -1) &&
                (!filter.address || client.address.indexOf(filter.address) > -1) &&
                (!filter.gstn_no || client.gstn_no.indexOf(filter.gstn_no) > -1) &&
                (!filter.tin_no || client.tin_no.indexOf(filter.tin_no) > -1) &&
                (filter.aadhar_number === undefined || client.aadhar_number === filter.aadhar_number) &&
                (!filter.nickName1 || client.nickName1.indexOf(filter.nickName1) > -1) &&
                (!filter.nickName2 || client.nickName2.indexOf(filter.nickName2) > -1);
              });
            }
          },


          insertItem: function(insertingClient) {
            db.customers.push(insertingClient);
            this.saveCustomer(insertingClient);
          },

          saveCustomer: function(insertingClient) {
            self.model.set(insertingClient);
            self.model.save({
             success : function (data) {
               console.log(data);
             }
           });
          },

          updateItem: function(updatingClient) {
            console.log("updateItem called");
            this.updateCustomer(updatingClient);
          },

          updateCustomer: function(updatingClient) {
            self.model.set(updatingClient);
            self.model.save({
             success : function (data) {
               console.log(data);
             }
           });
          },

          deleteItem: function(deletingClient) {
            console.log("deleteItem called");
            var clientIndex = $.inArray(deletingClient, db.customers);
            db.customers.splice(clientIndex, 1);
            this.deleteCustomer(deletingClient.attributes);
          },

          deleteCustomer: function(id) {
            self.model.set("id",id);
            self.model.destroy({
             success : function (data) {
               console.log(data);
             }
           });
          },


        },
        fields: [      
        {name: "customer_id",type: "text"}, 
        {name: "customer_name",type: "text"},
        {name: "primary_phno",type: "number"},
        {name: "secondary_phno",type: "number"},
        {name: "landline_no",type: "number"},
        {name: "emailaddress",type: "text"},
        {name: "address",type: "text"},
        {name: "gstn_no",type: "text"},
        {name: "tin_no",type: "text"},
        {name: "aadhar_number",type: "number"},
        {name: "nickName1",type: "text"},
        {name: "nickName2",type: "text"},
        { type: "control",editButton: true, deleteButton: true,
        itemTemplate: function(value, item) {
            var $result = jsGrid.fields.control.prototype.itemTemplate.apply(this, arguments);
            var $customEditButton = $("<button>").attr({class: "customGridDuplicatebutton "}).text("duplicate");
            /*.click(function(e) {
           // alert("ID: saveCustomer" + item.customer_id);

           this.duplicate();
           e.stopPropagation();
         }); */
           // return $("<div>").append($customEditButton);
            return $result.add($customEditButton);
          },
        }
        ]
      });
      //make get call for getting customer http://localhost:8080/customers/
      this.model.fetch({ 
       success : function (data) {
         if (data.attributes._embedded != undefined) {
           db.customers = data.attributes._embedded.customers;
          } 
        else {
          db.customers = [];
          }
        window.db = db;
                //$("#jsGrid").jsGrid("refresh");
                $("#jsGrid").jsGrid("render").done(function() {
                  console.log("rendering completed and data loaded");

                });
              }
            });

    },
  });
return SearchCustomerView;
});