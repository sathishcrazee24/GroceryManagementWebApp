
define([
	"jquery", 
	"backbone"  
	], function($, Backbone){
	   var CustomerModel = Backbone.Model.extend({	
	   
	  	url: '/customer',

	  	defaults : {
	  	customer_name : "SVN",
	  	category : "OIL",
	  	},
});
	return CustomerModel;
});