

define([
  "jquery",
  "underscore",
  "backbone",
  "handlebars",
  "JST"
  ], function($, _, Backbone, Handlebars,JST){

    var CustomerView = Backbone.View.extend({



     el: $("#page"),

     template: JST.customer_template,

      initialize: function () {
          this.render();
      },

     events: {
           "click  #customerSubmit" : "saveCustomer",
      },

      render: function () {          
          this.$el.html(this.template(this.model.attributes));
      },



      saveCustomer :function () {

         this.model.set("customer_name","customer_name");
        this.model.set("category","category");        
       this.model.save();
      }
 });

    return CustomerView;
  });