

define([
  "jquery",
  "underscore",
  "backbone",
  "handlebars",
  "JST",
  "HelperUtils",
  ], function($, _, Backbone, Handlebars,JST,HelperUtils){

    var CustomerView = Backbone.View.extend({el: $("#page"),
      template: JST.customer_template,

      initialize: function () {
        this.render();
      },

      events: {
       "click  #customerSubmit" : "saveCustomer",
     },
     render: function () {
      this.$el.html(this.template(this.model.attributes));
    },

    saveCustomer: function(e) {      
      e.preventDefault();
      this.model.set(HelperUtils.getFormData(this.$el.find('form')));
      this.model.save({ 
       success : function (data) {
         console.log(data);
       }
     });
    },
  });

    return CustomerView;
  });