
define([
	"jquery", 
	"backbone"  
	], function($, Backbone){
	   var SearchCustomerModel = Backbone.Model.extend({	   
	  	urlRoot: 'http://localhost:8080/customers',
		idAttribute: 'customer_id',
});
	return SearchCustomerModel;
});