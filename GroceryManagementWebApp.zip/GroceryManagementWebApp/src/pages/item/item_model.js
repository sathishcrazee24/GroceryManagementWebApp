
define([
	"jquery", 
	"backbone"  
	], function($, Backbone){
		var ItemModel = Backbone.Model.extend({	
			
			urlRoot: 'http://localhost:8080/items',
			idAttribute: '_id',

		});
		return ItemModel;
	});