

define([
  "jquery",
  "underscore",
  "backbone",
  "handlebars",
  "JST"
  ], function($, _, Backbone, Handlebars,JST){

    var ItemView = Backbone.View.extend({el: $("#page"),
      template: JST.item_template,

      initialize: function () {
        this.render();
      },

      events: {
       "click  #itemSubmit" : "saveItem",
     },
     render: function () {
      this.$el.html(this.template(this.model.attributes));
    },

    saveItem: function(e) {      
      e.preventDefault();
        //var item_data = JSON.stringify( this.getFormData( this.$el.find('form') ) );
        this.model.save(this.getFormData(this.$el.find('form')));        
          
          
          
        posts.fetch({
           dataType: 'jsonp',
           success : function (data) {
             console.log(data);
           }
        });


      },


      getFormData: function(form) {   
        var form = $(form).serializeArray();
        var formObject = {};
        $.each(form,
          function(i, v) {
            formObject[v.name] = v.value;
          });
        return formObject;
      },


    });

    return ItemView;
  });