

define([
  "jquery",
  "underscore",
  "backbone",
  "handlebars",
  "JST",
  "HelperUtils",
  ], function($, _, Backbone, Handlebars,JST,HelperUtils){

    var ItemView = Backbone.View.extend({el: $("#page"),
      template: JST.item_template,

      initialize: function () {
        this.render();
      },

      events: {
       "click  #itemSubmit" : "saveItem",
     },
     render: function () {
      this.$el.html(this.template(this.model.attributes));
    },

    saveItem: function(e) {      
      e.preventDefault();
      this.model.set(HelperUtils.getFormData(this.$el.find('form')));
      this.model.save({ 
       success : function (data) {
         console.log(data);
       }
     });
    },
  });

    return ItemView;
  });