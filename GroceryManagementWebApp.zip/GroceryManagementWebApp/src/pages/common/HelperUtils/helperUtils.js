

define([
  "jquery",
  "underscore",
  "backbone",
  "handlebars",
  ], function($, _, Backbone, Handlebars){


  	this.getFormData = function(form) {
        var form = $(form).serializeArray();
        var formObject = {};
        $.each(form,
          function(i, v) {
            formObject[v.name] = v.value;
          });
        return formObject;
      };
	  
	
	return this;
});