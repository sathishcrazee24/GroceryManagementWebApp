
define([
	"jquery", 
	"backbone"  
	], function($, Backbone){
	   var OrderModel = Backbone.Model.extend({	
	   
	  	urlRoot: 'http://localhost:8080/orders',
		//idAttribute: 'order_id',
});
	return OrderModel;
});