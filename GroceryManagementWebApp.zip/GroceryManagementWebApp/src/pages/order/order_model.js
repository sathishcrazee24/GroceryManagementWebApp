
define([
	"jquery", 
	"backbone"  
	], function($, Backbone){
	   var OrderModel = Backbone.Model.extend({	
	   
	  	url: '/order',

	  	defaults : {
	  	item_name : "SVN",
	  	category : "OIL",
	  	},
});
	return OrderModel;
});