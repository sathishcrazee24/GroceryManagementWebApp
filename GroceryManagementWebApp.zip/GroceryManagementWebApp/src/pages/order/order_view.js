

define([
  "jquery",
  "underscore",
  "backbone",
  "handlebars",
  "JST",
  "HelperUtils",
  'pages/order/order_item_model',
  ], function($, _, Backbone, Handlebars,JST,HelperUtils,OrderItemsModel){

    var OrderView = Backbone.View.extend({el: $("#page"),
      template: JST.order_template,

      initialize: function () {
        db.orderItems = [];
        this.orderItemsModel=new OrderItemsModel();
        this.render();
      },

      events: {
       "click  #orderSubmit" : "saveOrder",
     },
     render: function () {
      this.$el.html(this.template(this.model.attributes));
    },

    saveOrder: function(e) {
      var self =this;      
      e.preventDefault();
      self.model.set(HelperUtils.getFormData(this.$el.find('form')));
      self.model.save(null,        
      {
        url : "http://localhost:8080/orders", 
        async : false,
        success: function (model, response) {       
          $('#mySucessModal').modal('show');
          console.log("success",response);
          $('#order_id').val(response.order_id);
          $("form :input").attr("disabled","disabled");
          self.initializeJsGrid();       
        },
        error: function (model, response) {         
          $('#myErrorModal').modal('show');
          console.log("error",response);
        }
      });
    },

    initializeJsGrid:function(){

      var origFinishInsert = jsGrid.loadStrategies.DirectLoadingStrategy.prototype.finishInsert;
      jsGrid.loadStrategies.DirectLoadingStrategy.prototype.finishInsert = function (insertItem) {
            if (this._grid.insertFailed) { // define insertFailed on done of insert ajax request in insertFailed of controller
              return;
            }
            origFinishInsert.apply(this, arguments);
          };


          var self =this;

          var grid = $("#jsGrid").jsGrid({
            /*height: "100%",*/
            width: "100%",
            inserting: true,
            /*filtering: true,*/
            editing: true,
            sorting: true,
            paging: true,
            autoload: true,
            pageSize: 15,
            pageButtonCount: 5,
            deleteConfirm: "Do you really want to delete the orderItem?",
            controller: {
              loadData: function(filter) {
                if(db === undefined || (db != undefined && db.orderItems === undefined))
                {
                  return [];
                }
                else
                {
                  return $.grep(db.orderItems, function(client) {
                    return  (!filter.order_id || client.order_id.indexOf(filter.order_id) > -1) &&
                    (!filter.item_name || client.item_name.indexOf(filter.item_name) > -1) &&
                    (!filter.order_qty || client.order_qty.indexOf(filter.order_qty) > -1) &&
                    (!filter.rate || client.rate.indexOf(filter.rate) > -1) &&
                    (!filter.order_unit || client.order_unit.indexOf(filter.order_unit) > -1) &&
                    (!filter.cgst_percentage || client.cgst_percentage.indexOf(filter.cgst_percentage) > -1) &&
                    (!filter.sgst_percentage || client.sgst_percentage.indexOf(filter.sgst_percentage) > -1) &&
                    (!filter.cgst_amt || client.cgst_amt.indexOf(filter.cgst_amt) > -1) &&
                    (!filter.sgst_amt || client.sgst_amt.indexOf(filter.sgst_amt) > -1) &&
                    (!filter.net_rate || client.net_rate.indexOf(filter.net_rate) > -1) &&
                    (!filter.hsbn_code || client.hsbn_code.indexOf(filter.hsbn_code) > -1) &&
                    (!filter.category || client.category.indexOf(filter.category) > -1) &&
                    (!filter.bill_no_consumed || client.bill_no_consumed.indexOf(filter.bill_no_consumed) > -1);
                  });
                }
              },


              insertItem: function(insertingClient) {
            //db.orderItems.push(insertingClient);
            this.saveOrderItems(insertingClient);
          },

          saveOrderItems: function(insertingClient) {    
            self.orderItemsModel.set(insertingClient);        
            self.orderItemsModel.save(null,      
            {
              async : false,                     
              success: function (model, response) { 
                grid.insertFailed = false;
                insertingClient.record_id=response.record_id;
                db.orderItems.push(insertingClient);                
                console.log("success",response);        
              },
              error: function (model, response) {
                grid.insertFailed = true;
                console.log("error",response);
              }
            });
          },

          updateItem: function(updatingClient) {
            console.log("updateItem called");
            this.updateOrderItems(updatingClient);
          },

          updateOrderItems: function(updatingClient) {
            self.orderItemsModel.set(updatingClient);
            self.orderItemsModel.save(null,        
            {
              async : false,
              success: function (model, response) { 
                console.log("success",response);        
              },
              error: function (model, response) {
                console.log("error",response);
              }
            });
          },

          deleteItem: function(deletingClient) {
            console.log("deleteItem called");
            var clientIndex = $.inArray(deletingClient, db.orderItems);
            db.orderItems.splice(clientIndex, 1);
            this.deleteOrderItems(deletingClient.record_id);
          },

          deleteOrderItems: function(record_id) {
            var newOrderItemsModel=new OrderItemsModel();
            newOrderItemsModel.set("record_id",record_id);
            newOrderItemsModel.destroy(null,{
             async : false,             
             success: function (model, response) { 
              console.log("success",response);        
            },
            error: function (model, response) {
              console.log("error",response);
            }
          });
          },


        },
        fields: [
        {name: "record_id",type: "number",readOnly: true},       
        {name: "order_id",type: "text"}, 
        {name: "item_name",type: "text"},
        {name: "order_qty",type: "text"},
        {name: "rate",type: "text"},
        {name: "order_unit",type: "text"},
        {name: "cgst_percentage",type: "text"},
        {name: "sgst_percentage",type: "text"},
        {name: "cgst_amt",type: "text"},
        {name: "sgst_amt",type: "text"},
        {name: "net_rate",type: "text"},
        {name: "hsbn_code",type: "text"},
        {name: "category",type: "text"},
        {name: "bill_no_consumed",type: "text"},        
        { type: "control",editButton: true, deleteButton: true,
        itemTemplate: function(value, item) {
          var $result = jsGrid.fields.control.prototype.itemTemplate.apply(this, arguments);
          var $customEditButton = $("<button>").attr({class: "customGridDuplicatebutton "}).text("duplicate");
            /*.click(function(e) {
           // alert("ID: saveCustomer" + item.customer_id);

           this.duplicate();
           e.stopPropagation();
         }); */
           // return $("<div>").append($customEditButton);
           return $result.add($customEditButton);
         },
       }
       ]
     }).data("JSGrid");






      //make get call for getting customer http://localhost:8080/customers/
      this.orderItemsModel.fetch(null,        
      {        
        async : false,        
        success : function (data) {
           if (data.attributes._embedded != undefined) {
             db.orderItems = data.attributes._embedded.orderItems;
            } 
          else {
            db.orderItems = [];
            }
          window.db = db;
                //$("#jsGrid").jsGrid("refresh");
                $("#jsGrid").jsGrid("render").done(function() {
                  console.log("rendering completed and data loaded");

                });
              }
            });

    },




  });

return OrderView;
});