define([
  "jquery",
  "underscore",
  "backbone",
  "handlebars",
  "JST"
  ], function($, _, Backbone, Handlebars,JST){

    var OrderView = Backbone.View.extend({



 
     el: $("#page"),

     template: JST.order_template,

      initialize: function () {
          this.render();
      },

     events: {
           "click  #orderSubmit" : "saveOrder",
      },

      render: function () {          
          this.$el.html(this.template(this.model.attributes));
      },



      saveOrder :function () {

         this.model.set("item_name","item_name");
        this.model.set("category","category");        
       this.model.save();
      }
 });

    return OrderView;
  });