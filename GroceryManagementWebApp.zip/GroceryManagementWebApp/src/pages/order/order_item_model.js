
define([
	"jquery", 
	"backbone"  
	], function($, Backbone){
	   var OrderItemsModel = Backbone.Model.extend({	
	   
	  	urlRoot: 'http://localhost:8080/orderItems',
		//idAttribute: 'record_id',

		//comment id update works

		//uncommet id delte works
});
	return OrderItemsModel;
});