
define([
	"jquery", 
	"backbone"  
	], function($, Backbone){
	   var OrderItemsModel = Backbone.Model.extend({	
	   
	  	urlRoot: 'http://localhost:8080/orderItems',
		idAttribute: 'record_id',
});
	return OrderItemsModel;
});