// Filename: router.js
define([
  'jquery',
  'underscore',
  'backbone',
  'pages/item/item_view',
  'pages/item/item_model',
  'pages/customer/customer_view',
  'pages/customer/customer_model',
  'pages/customer/search_customer_view',
  'pages/customer/search_customer_model',
  'pages/vendor/vendor_view',
  'pages/vendor/vendor_model',
  'pages/order/order_view',
  'pages/order/order_model',
  'pages/bill/bill_view',
  'pages/bill/bill_model',
  ], function($, _, Backbone, ItemView,ItemModel,CustomerView,CustomerModel,SearchCustomerView,SearchCustomerModel,VendorView,VendorModel,OrderView,OrderModel,BillView,BillModel/*,HeaderView,FooterView*/) {

    var AppRouter = Backbone.Router.extend({
      routes: {      
        '': 'showItem',   
        'customer': 'showCustomer',  
        'search_customer': 'showSearchCustomer',    
        'vendor': 'showVendor',   
        'order': 'showOrder',   
        'bill': 'showBill',
        'item': 'showItem',   

      },
      showCustomer : function(){
      $('#jsGrid').jsGrid("destroy");
       var customerView = new CustomerView({model:new CustomerModel()});
     },

      showSearchCustomer : function(){
       var search_customerView = new SearchCustomerView({model:new SearchCustomerModel()});
     },
     showVendor : function(){
      $('#jsGrid').jsGrid("destroy");
       var vendorView = new VendorView({model:new VendorModel()});
     },

     showOrder : function(){
      $('#jsGrid').jsGrid("destroy");
       var orderView = new OrderView({model:new OrderModel()});
     },
     showBill : function(){
      $('#jsGrid').jsGrid("destroy");
       var billView = new BillView({model:new BillModel()});
     },
     showItem : function(){
      $('#jsGrid').jsGrid("destroy");
       var itemView = new ItemView({model:new ItemModel()});
     }

   });

    var initialize = function(){
      var app_router = new AppRouter;    
     Backbone.history.start();    
   };

   return { 
    initialize: initialize
  };
});
