package demo;

public class Input_generator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	

	   // generateCustomer();

	    //generateVendor();
		
		//generateBill();
		
		generateOrder();
	}

	private static void generateOrder() {


		// TODO Auto-generated method stub
		String labels= "Order Date,Category,Customer Name,Customer GST,Item Name,Unit/Weight,Quantity,Price Per Quantity,CGST Percentage,SGST Percentage,CGST Amount,SGST Amount,Total amount,Aadhar number,Vehicle number,Bill no Consumed";
		String input= "order_date;category;customer_name;customer_gst;item_name;order_unit;order_qty;price_per_qty;cgst_percentage;sgst_percentage;cgst_amt;sgst_amt;tot_amt;contact_number;aadhar_no;vehicle_no;bill_no_consumed;";

		String labelArr[] = labels.split(",");
		String inputArr[] = input.split(";");
		
		for(int i=0;i<labelArr.length;i++)
		{
		
			System.out.println("<div class= \"row form-group\">");
			System.out.println("<div class=\"col-xs-3\">");
			System.out.println("  <label class=\"control-label\" for=\""+inputArr[i]+"\">"+labelArr[i]+": </label>");
			System.out.println("</div>");
			System.out.println("<div class=\"col-xs-9\">");
			System.out.println("  <input type=\"text\" class=\"form-control\" id=\""+inputArr[i]+"\" placeholder=\"\">");
			System.out.println("</div>");
			System.out.println("</div>");
			System.out.println();
		}
		
	
		
	
		
	}

	private static void generateBill() {

		// TODO Auto-generated method stub
		String labels= "Category,Vendor Name,Bill Date,Bill Number,Item Name,Quantity,Unit,Price,CGST Percentage,SGST Percentage,SGST Amount,CGST Amount,Due Date";
		String input= "category;vendor_name;bill_date;bill_number;item_name;qty;qty_unit;price_per_qty;cgst_percentage;sgst_percentage;cgst_amt;sgst_amt;due_date;";

		String labelArr[] = labels.split(",");
		String inputArr[] = input.split(";");
		
		for(int i=0;i<labelArr.length;i++)
		{
		
			System.out.println("<div class= \"row form-group\">");
			System.out.println("<div class=\"col-xs-3\">");
			System.out.println("  <label class=\"control-label\" for=\""+inputArr[i]+"\">"+labelArr[i]+": </label>");
			System.out.println("</div>");
			System.out.println("<div class=\"col-xs-9\">");
			System.out.println("  <input type=\"text\" class=\"form-control\" id=\""+inputArr[i]+"\" placeholder=\"\">");
			System.out.println("</div>");
			System.out.println("</div>");
			System.out.println();
		}
		
	
		
	}

	private static void generateCustomer() {
		// TODO Auto-generated method stub
		String labels= "Customer Name,Primary mobile number,Primary mobile number,Landline Number ,Email address,Address,GST Number,TIN Number,Aadhar Number,NickName1,Nickname2";
		String input= "customer_name,primary_phno,secondary_phno,landline_no,emailaddress,address,gstn_no,tin_no,aadhar_number,nickName1,nickName2";
		String labelArr[] = labels.split(",");
		String inputArr[] = input.split(",");
		
		for(int i=0;i<labelArr.length;i++)
		{
		
			System.out.println("<div class= \"row form-group\">");
			System.out.println("<div class=\"col-xs-3\">");
			System.out.println("  <label class=\"control-label\" for=\""+inputArr[i]+"\">"+labelArr[i]+": </label>");
			System.out.println("</div>");
			System.out.println("<div class=\"col-xs-9\">");
			System.out.println("  <input type=\"text\" class=\"form-control\" id=\""+inputArr[i]+"\" placeholder=\"\">");
			System.out.println("</div>");
			System.out.println("</div>");
			System.out.println();
		}
		
	}
	
	
	private static void generateVendor() {
		// TODO Auto-generated method stub
		String labels= "Vendor Name,Primary mobile number,Primary mobile number,Landline Number,Email address,Address,GST Number,TIN Number,NickName1,Nickname2";
		String input= "vendor_name;primary_phno;secondary_phno;landline_no;emailaddress;address;gstn_no;tin_no;nickName1;nickName2;";
		String labelArr[] = labels.split(",");
		String inputArr[] = input.split(";");
		
		for(int i=0;i<labelArr.length;i++)
		{
		
			System.out.println("<div class= \"row form-group\">");
			System.out.println("<div class=\"col-xs-3\">");
			System.out.println("  <label class=\"control-label\" for=\""+inputArr[i]+"\">"+labelArr[i]+": </label>");
			System.out.println("</div>");
			System.out.println("<div class=\"col-xs-9\">");
			System.out.println("  <input type=\"text\" class=\"form-control\" id=\""+inputArr[i]+"\" placeholder=\"\">");
			System.out.println("</div>");
			System.out.println("</div>");
			System.out.println();
		}
		
	}
	
	
	

}
