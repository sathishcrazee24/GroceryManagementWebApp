package demo;

public class Input_generator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub



		//generateCustomer();

		//generateVendor();

		//generateBill();

		//generateOrder();
		
		generateGrepTextForOrderItems();
		
		//generateGrepText();
		
	}

	
	
	private static void generateGrepText() {
		
		String input= "customer_name,primary_phno,secondary_phno,landline_no,emailaddress,address,gstn_no,tin_no,aadhar_number,nickName1,nickName2";
		String inputArr[] = input.split(",");
		for(int i=0;i<inputArr.length;i++)
		{
			System.out.println("(!filter."+inputArr[i]+" || client."+inputArr[i]+".indexOf(filter."+inputArr[i]+") > -1) &&");
		}
		//"+inputArr[i]+"
		
	}
	
	
private static void generateGrepTextForOrderItems() {
		
		String input= "order_id;item_name;order_qty;rate;order_unit;cgst_percentage;sgst_percentage;cgst_amt;sgst_amt;net_rate;hsbn_code;category;bill_no_consumed;";
		String inputArr[] = input.split(";");
		for(int i=0;i<inputArr.length;i++)
		{
			System.out.println("(!filter."+inputArr[i]+" || client."+inputArr[i]+".indexOf(filter."+inputArr[i]+") > -1) &&");
		}
		//"+inputArr[i]+"
		
	}



	private static void generateOrder() {
		

		// TODO Auto-generated method stub
		String labels= "Order Id,Order Date,Customer Name,Customer GST,Contact number,Aadhar number,Vehicle number";
		String input= "order_id;order_date;customer_name;customer_gst;contact_number;aadhar_no;vehicle_no;";
		String labelArr[] = labels.split(",");
		String inputArr[] = input.split(";");		
		generateInputs(labelArr,inputArr);
	}

	private static void generateInputs(String[] labelArr, String[] inputArr) {
		for(int i=0;i<labelArr.length;i++)
		{
			String inputElement =inputArr[i];
			if(inputElement.contains("category") || inputElement.contains("unit") )
			{

				System.out.println("<div class= \"row form-group\">");
				System.out.println("<div class=\"col-xs-3\">");
				System.out.println("  <label class=\"control-label\" for=\""+inputArr[i]+"\">"+labelArr[i]+": </label>");
				System.out.println("</div>");
				System.out.println("<div class=\"col-xs-9\">");
				System.out.println("<select class=\"form-control\" name = \""+inputArr[i]+"\" id=\""+inputArr[i]+"\">");
				System.out.println("<option>--select--</option>");
				if(inputElement.contains("category"))
				{
					System.out.println("<option>SUGAR</option>");
					System.out.println("<option>OIL</option>");
					System.out.println("<option>GROCERY</option>");
				}
				else
				{
					System.out.println("<option>100KG</option>");
					System.out.println("<option>50KG</option>");
					System.out.println("<option>30KG</option>");
					System.out.println("<option>25KG</option>");
					System.out.println("<option>15KG</option>");
					System.out.println("<option>10KG</option>");				
				}
				System.out.println("</select>");
				System.out.println("</div>");
				System.out.println("</div>");
				System.out.println();

			}else
			{
				System.out.println("<div class= \"row form-group\">");
				System.out.println("<div class=\"col-xs-3\">");
				System.out.println("  <label class=\"control-label\" for=\""+inputArr[i]+"\">"+labelArr[i]+": </label>");
				System.out.println("</div>");
				System.out.println("<div class=\"col-xs-9\">");
				System.out.println("<input type=\"text\" class=\"form-control\" name = \""+inputArr[i]+"\" id=\""+inputArr[i]+"\" placeholder=\"\">");
				System.out.println("</div>");
				System.out.println("</div>");
				System.out.println();
			}
		}
		
	}



	private static void generateBill() {

		// TODO Auto-generated method stub
		String labels= "Category,Vendor Name,Bill Date,Bill Number,Item Name,Quantity,Unit,Price,CGST Percentage,SGST Percentage,SGST Amount,CGST Amount,Due Date";
		String input= "category;vendor_name;bill_date;bill_number;item_name;qty;qty_unit;price_per_qty;cgst_percentage;sgst_percentage;cgst_amt;sgst_amt;due_date;";

		String labelArr[] = labels.split(",");
		String inputArr[] = input.split(";");
		generateInputs(labelArr,inputArr);



	}

	private static void generateCustomer() {
		// TODO Auto-generated method stub
		String labels= "Customer Name,Primary mobile number,Primary mobile number,Landline Number ,Email address,Address,GST Number,TIN Number,Aadhar Number,NickName1,Nickname2";
		String input= "customer_name,primary_phno,secondary_phno,landline_no,emailaddress,address,gstn_no,tin_no,aadhar_number,nickName1,nickName2";
		String labelArr[] = labels.split(",");
		String inputArr[] = input.split(",");

		generateInputs(labelArr,inputArr);

	}


	private static void generateVendor() {
		// TODO Auto-generated method stub
		String labels= "Vendor Name,Primary mobile number,Primary mobile number,Landline Number,Email address,Address,GST Number,TIN Number,NickName1,Nickname2";
		String input= "vendor_name;primary_phno;secondary_phno;landline_no;emailaddress;address;gstn_no;tin_no;nickName1;nickName2;";
		String labelArr[] = labels.split(",");
		String inputArr[] = input.split(";");
		generateInputs(labelArr,inputArr);

	}




}
