package demo;

import org.springframework.context.annotation.Configuration;
import org.springframework.data.rest.core.config.RepositoryRestConfiguration;
import org.springframework.data.rest.webmvc.config.RepositoryRestConfigurerAdapter;



import demo.model.Order;
import demo.model.OrderItem;

@Configuration
public class RepositoryConfiguration extends RepositoryRestConfigurerAdapter {

    @Override
    public void configureRepositoryRestConfiguration(RepositoryRestConfiguration config) {
        
       /* config.exposeIdsFor(Item.class);*/
    	config.exposeIdsFor(OrderItem.class);
        config.exposeIdsFor(Order.class);
       
        /*config.exposeIdsFor(Comment.class);*/
    }
}