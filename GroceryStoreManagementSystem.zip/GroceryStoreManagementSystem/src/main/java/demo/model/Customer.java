package demo.model;
import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Customer {
	@Column private static final long serialVersionUID = 1L;
	
	@Id	
	@GeneratedValue(strategy = GenerationType.AUTO)
    @Column private long customer_id;
	@Column private String customer_name;
	@Column private long primary_phno;
    @Column private long secondary_phno;
    @Column private long landline_no;
    @Column private String emailaddress;
    @Column private String address;
    @Column private String gstn_no;
    @Column private String tin_no;
    @Column private String aadhar_number;
    @Column private String nickName1;
    @Column private String nickName2;
	public long getCustomer_id() {
		return customer_id;
	}
	public void setCustomer_id(long customer_id) {
		this.customer_id = customer_id;
	}
	public String getCustomer_name() {
		return customer_name;
	}
	public void setCustomer_name(String customer_name) {
		this.customer_name = customer_name;
	}
	public long getPrimary_phno() {
		return primary_phno;
	}
	public void setPrimary_phno(long primary_phno) {
		this.primary_phno = primary_phno;
	}
	public long getSecondary_phno() {
		return secondary_phno;
	}
	public void setSecondary_phno(long secondary_phno) {
		this.secondary_phno = secondary_phno;
	}
	public long getLandline_no() {
		return landline_no;
	}
	public void setLandline_no(long landline_no) {
		this.landline_no = landline_no;
	}
	public String getEmailaddress() {
		return emailaddress;
	}
	public void setEmailaddress(String emailaddress) {
		this.emailaddress = emailaddress;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getGstn_no() {
		return gstn_no;
	}
	public void setGstn_no(String gstn_no) {
		this.gstn_no = gstn_no;
	}
	public String getTin_no() {
		return tin_no;
	}
	public void setTin_no(String tin_no) {
		this.tin_no = tin_no;
	}
	public String getNickName1() {
		return nickName1;
	}
	public void setNickName1(String nickName1) {
		this.nickName1 = nickName1;
	}
	public String getNickName2() {
		return nickName2;
	}
	public void setNickName2(String nickName2) {
		this.nickName2 = nickName2;
	}
    
	
}
