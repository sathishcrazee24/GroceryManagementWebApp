package demo.model;
import javax.persistence.Column;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Formatter;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="ORDERS")
public class Order {
	
	@Id	
	@GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name="order_id") private long order_id;
    //@Column(name="customer_id") private String customer_id;
    @Column(name="customer_name") private String customer_name;
    @Column(name="order_date") private Date order_date;
    @Column(name="order_month") private String order_month;
    @Column(name="customer_gst") private String customer_gst;   
    @Column private long contact_number;
    @Column private long total_amuount;
    @Column private String aadhar_no;
    @Column private String vehicle_no;
    
	public long getOrder_id() {
		return order_id;
	}
	public void setOrder_id(long order_id) {
		this.order_id = order_id;
	}
	public String getCustomer_name() {
		return customer_name;
	}
	public void setCustomer_name(String customer_name) {
		this.customer_name = customer_name;
	}
	public Date getOrder_date() {
		return order_date;
	}
	public void setOrder_date(Date order_date) {
		this.order_date = order_date;
	}
	public String getOrder_month() {
		return order_month;
	}
	public void setOrder_month(String order_month) {
		this.order_month = order_month;
	}
	public String getCustomer_gst() {
		return customer_gst;
	}
	public void setCustomer_gst(String customer_gst) {
		this.customer_gst = customer_gst;
	}
	public long getContact_number() {
		return contact_number;
	}
	public void setContact_number(long contact_number) {
		this.contact_number = contact_number;
	}
	public String getAadhar_no() {
		return aadhar_no;
	}
	public void setAadhar_no(String aadhar_no) {
		this.aadhar_no = aadhar_no;
	}
	public String getVehicle_no() {
		return vehicle_no;
	}
	public void setVehicle_no(String vehicle_no) {
		this.vehicle_no = vehicle_no;
	}
	public long getTotal_amuount() {
		return total_amuount;
	}
	public void setTotal_amuount(long total_amuount) {
		this.total_amuount = total_amuount;
	}
}