package demo.model;
import javax.persistence.Column;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="ORDERS")
public class Order {
	
	@Id	
	@GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name="order_id") private long order_id;
    @Column(name="customer_id") private String customer_id;
    @Column(name="customer_name") private String customer_name;
    @Column(name="order_date") private Date order_date;
    @Column(name="order_month") private String order_month;
    @Column(name="customer_gst") private String customer_gst;
    @Column private String item_name;
    @Column private String order_qty;
    @Column private String price_per_qty;
    @Column private String order_unit;    
    @Column private double cgst_percentage;
    @Column private double sgst_percentage;
    @Column private double cgst_amt;
    @Column private double sgst_amt;
    @Column private double tot_amt;
    @Column private long contact_number;
    @Column private String aadhar_no;
    @Column private String vehicle_no;
    @Column private String bill_no_consumed;
    @Column private String hsbn_code;
    @Column private String category;
	public long getOrder_id() {
		return order_id;
	}
	public void setOrder_id(long order_id) {
		this.order_id = order_id;
	}
	public String getCustomer_id() {
		return customer_id;
	}
	public void setCustomer_id(String customer_id) {
		this.customer_id = customer_id;
	}
	public String getCustomer_name() {
		return customer_name;
	}
	public void setCustomer_name(String customer_name) {
		this.customer_name = customer_name;
	}
	public Date getOrder_date() {
		return order_date;
	}
	public void setOrder_date(Date order_date) {
		this.order_date = order_date;
	}
	public String getOrder_month() {
		return order_month;
	}
	public void setOrder_month(String order_month) {
		this.order_month = order_month;
	}
	public String getCustomer_gst() {
		return customer_gst;
	}
	public void setCustomer_gst(String customer_gst) {
		this.customer_gst = customer_gst;
	}
	public String getItem_name() {
		return item_name;
	}
	public void setItem_name(String item_name) {
		this.item_name = item_name;
	}
	public String getOrder_qty() {
		return order_qty;
	}
	public void setOrder_qty(String order_qty) {
		this.order_qty = order_qty;
	}
	public String getPrice_per_qty() {
		return price_per_qty;
	}
	public void setPrice_per_qty(String price_per_qty) {
		this.price_per_qty = price_per_qty;
	}
	public String getOrder_unit() {
		return order_unit;
	}
	public void setOrder_unit(String order_unit) {
		this.order_unit = order_unit;
	}
	public double getCgst_percentage() {
		return cgst_percentage;
	}
	public void setCgst_percentage(double cgst_percentage) {
		this.cgst_percentage = cgst_percentage;
	}
	public double getSgst_percentage() {
		return sgst_percentage;
	}
	public void setSgst_percentage(double sgst_percentage) {
		this.sgst_percentage = sgst_percentage;
	}
	public double getCgst_amt() {
		return cgst_amt;
	}
	public void setCgst_amt(double cgst_amt) {
		this.cgst_amt = cgst_amt;
	}
	public double getSgst_amt() {
		return sgst_amt;
	}
	public void setSgst_amt(double sgst_amt) {
		this.sgst_amt = sgst_amt;
	}
	public long getContact_number() {
		return contact_number;
	}
	public void setContact_number(long contact_number) {
		this.contact_number = contact_number;
	}
	public String getAadhar_no() {
		return aadhar_no;
	}
	public void setAadhar_no(String aadhar_no) {
		this.aadhar_no = aadhar_no;
	}
	public String getVehicle_no() {
		return vehicle_no;
	}
	public void setVehicle_no(String vehicle_no) {
		this.vehicle_no = vehicle_no;
	}
	public String getBill_no_consumed() {
		return bill_no_consumed;
	}
	public void setBill_no_consumed(String bill_no_consumed) {
		this.bill_no_consumed = bill_no_consumed;
	}
	public String getHsbn_code() {
		return hsbn_code;
	}
	public void setHsbn_code(String hsbn_code) {
		this.hsbn_code = hsbn_code;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
    
    }
