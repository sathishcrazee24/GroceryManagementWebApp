package demo.model;
import javax.persistence.Column;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Formatter;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="ORDER_ITEMS")
public class OrderItem {

	@Id		
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="RECORD_ID") private Long record_id;	
	@Column private String item_name;	
    @Column(name="order_id") private long order_id;    
    @Column private Integer order_qty;
    @Column private double rate;
    @Column private String order_unit;    
    @Column private double cgst_percentage;
    @Column private double sgst_percentage;
    @Column private double cgst_amt;
    @Column private double sgst_amt;
    @Column private double net_rate;
    @Column private String hsbn_code;
    @Column private String category;
    @Column private String bill_no_consumed;
    @Column private double order_total;
    
	public String getItem_name() {
		return item_name;
	}
	public void setItem_name(String item_name) {
		this.item_name = item_name;
	}
	public long getOrder_id() {
		return order_id;
	}
	public void setOrder_id(long order_id) {
		this.order_id = order_id;
	}
	public Integer getOrder_qty() {
		return order_qty;
	}
	public void setOrder_qty(Integer itemQty) {
		this.order_qty = itemQty;
	}

	public String getOrder_unit() {
		return order_unit;
	}
	public void setOrder_unit(String order_unit) {
		this.order_unit = order_unit;
	}
	public double getCgst_percentage() {
		return cgst_percentage;
	}
	public void setCgst_percentage(double cgst_percentage) {
		this.cgst_percentage = cgst_percentage;
	}
	public double getSgst_percentage() {
		return sgst_percentage;
	}
	public void setSgst_percentage(double sgst_percentage) {
		this.sgst_percentage = sgst_percentage;
	}
	public double getCgst_amt() {
		return cgst_amt;
	}
	public void setCgst_amt(double cgst_amt) {
		this.cgst_amt = cgst_amt;
	}
	public double getSgst_amt() {
		return sgst_amt;
	}
	public void setSgst_amt(double sgst_amt) {
		this.sgst_amt = sgst_amt;
	}
	public double getNet_rate() {
		return net_rate;
	}
	public void setNet_rate(double net_rate) {
		this.net_rate = net_rate;
	}
	public String getHsbn_code() {
		return hsbn_code;
	}
	public void setHsbn_code(String hsbn_code) {
		this.hsbn_code = hsbn_code;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getBill_no_consumed() {
		return bill_no_consumed;
	}
	public void setBill_no_consumed(String bill_no_consumed) {
		this.bill_no_consumed = bill_no_consumed;
	}
	public Long getRecord_id() {
		return record_id;
	}
	public void setRecord_id(Long record_id) {
		this.record_id = record_id;
	}
	public double getRate() {
		return rate;
	}
	public void setRate(double rate) {
		this.rate = rate;
	}
	public double getOrder_total() {
		return order_total;
	}
	public void setOrder_total(double order_total) {
		this.order_total = order_total;
	}
	
}