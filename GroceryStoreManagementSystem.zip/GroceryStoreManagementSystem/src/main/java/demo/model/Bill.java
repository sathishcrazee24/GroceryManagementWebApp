package demo.model;
import javax.persistence.Column;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
@Entity
public class Bill {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
    @Column private long bill_id;
	@Column private String bill_number;
    @Column private int qty;
    @Column private String qty_unit;    
    @Column private String item_name;  
    @Column private String category;//sfbox/gnbox/sugar/dhal
    @Column private boolean payment_completed;
    @Column private String rtgsNumber;    
    @Column private String chequeNumber;
    @Column private Date bill_date;
    @Column private String bill_month;
    @Column private Date due_date;
    @Column private String due_month;
    @Column private Date payment_date; //rtgs date
    @Column private String payment_month; //rtgs month
    @Column private double tot_bill_amount;
    @Column private double price_per_qty;//tot amt =amt_per_qty*qty* +cgst+sgst
    @Column private double cgst_percentage;
    @Column private double sgst_percentage;
    @Column private double cgst_amt;
    @Column private double sgst_amt;
    @Column private String vendor_name;    
    @Column private String hsbn_code;
	public long getBill_id() {
		return bill_id;
	}
	public void setBill_id(long bill_id) {
		this.bill_id = bill_id;
	}
	public String getBill_number() {
		return bill_number;
	}
	public void setBill_number(String bill_number) {
		this.bill_number = bill_number;
	}
	public int getQty() {
		return qty;
	}
	public void setQty(int qty) {
		this.qty = qty;
	}
	public String getQty_unit() {
		return qty_unit;
	}
	public void setQty_unit(String qty_unit) {
		this.qty_unit = qty_unit;
	}
	public String getItem_name() {
		return item_name;
	}
	public void setItem_name(String item_name) {
		this.item_name = item_name;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public boolean isPayment_completed() {
		return payment_completed;
	}
	public void setPayment_completed(boolean payment_completed) {
		this.payment_completed = payment_completed;
	}
	public String getRtgsNumber() {
		return rtgsNumber;
	}
	public void setRtgsNumber(String rtgsNumber) {
		this.rtgsNumber = rtgsNumber;
	}
	public String getChequeNumber() {
		return chequeNumber;
	}
	public void setChequeNumber(String chequeNumber) {
		this.chequeNumber = chequeNumber;
	}
	public Date getBill_date() {
		return bill_date;
	}
	public void setBill_date(Date bill_date) {
		this.bill_date = bill_date;
	}
	public String getBill_month() {
		return bill_month;
	}
	public void setBill_month(String bill_month) {
		this.bill_month = bill_month;
	}
	public Date getDue_date() {
		return due_date;
	}
	public void setDue_date(Date due_date) {
		this.due_date = due_date;
	}
	public String getDue_month() {
		return due_month;
	}
	public void setDue_month(String due_month) {
		this.due_month = due_month;
	}
	public Date getPayment_date() {
		return payment_date;
	}
	public void setPayment_date(Date payment_date) {
		this.payment_date = payment_date;
	}
	public String getPayment_month() {
		return payment_month;
	}
	public void setPayment_month(String payment_month) {
		this.payment_month = payment_month;
	}
	public double getTot_bill_amount() {
		return tot_bill_amount;
	}
	public void setTot_bill_amount(double tot_bill_amount) {
		this.tot_bill_amount = tot_bill_amount;
	}
	public double getPrice_per_qty() {
		return price_per_qty;
	}
	public void setPrice_per_qty(double price_per_qty) {
		this.price_per_qty = price_per_qty;
	}
	public double getCgst_percentage() {
		return cgst_percentage;
	}
	public void setCgst_percentage(double cgst_percentage) {
		this.cgst_percentage = cgst_percentage;
	}
	public double getSgst_percentage() {
		return sgst_percentage;
	}
	public void setSgst_percentage(double sgst_percentage) {
		this.sgst_percentage = sgst_percentage;
	}
	public double getCgst_amt() {
		return cgst_amt;
	}
	public void setCgst_amt(double cgst_amt) {
		this.cgst_amt = cgst_amt;
	}
	public double getSgst_amt() {
		return sgst_amt;
	}
	public void setSgst_amt(double sgst_amt) {
		this.sgst_amt = sgst_amt;
	}
	public String getVendor_name() {
		return vendor_name;
	}
	public void setVendor_name(String vendor_name) {
		this.vendor_name = vendor_name;
	}
	public String getHsbn_code() {
		return hsbn_code;
	}
	public void setHsbn_code(String hsbn_code) {
		this.hsbn_code = hsbn_code;
	}
    

}