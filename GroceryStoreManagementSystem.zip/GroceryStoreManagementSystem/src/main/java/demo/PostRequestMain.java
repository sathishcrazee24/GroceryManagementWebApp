package demo;

import org.springframework.web.client.RestTemplate;

import demo.model.Order;
import demo.model.OrderItem;

public class PostRequestMain {
	RestTemplate restTemplate = new RestTemplate();
	String  order_uri= "http://localhost:8080/orders/";
	String  order_item_uri= "http://localhost:8080/orderItems/";
	public static void main(String[] args) {	
		PostRequestMain pm =new PostRequestMain();
		
		
		
		Order order=new Order();
		order.setCustomer_name("saravanan2");
		order.setVehicle_no("TN23");		
		Order ord= pm.addOrder(order);
		pm.deleteOrder(ord.getOrder_id());
	}

	public Order addOrder(Order order)
	{	//OrderRepositoryImpl ord= new OrderRepositoryImpl();	
		Order addedOrder = restTemplate.postForObject( order_uri, order, Order.class);
		System.out.println("Country added : " +addedOrder.getOrder_id());   
		return addedOrder;
	}	
	
	public void deleteOrder(long order_id)
	{	  
		restTemplate.delete(order_uri+order_id);
	}

	public void addOrderItem(OrderItem prepareOrderitem) {
		
		OrderItem addedOrder = restTemplate.postForObject( order_item_uri, prepareOrderitem, OrderItem.class);
		System.out.println("OrderItem added : " +addedOrder.getOrder_id());   
		
	}
}
