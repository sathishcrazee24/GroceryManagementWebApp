package demo;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Random;

import demo.model.Order;
import demo.model.OrderItem;

public class RandomGenerator {

	static Calendar cal = Calendar.getInstance();
	static boolean timeSet=false;
	int profitDecidedForSugar=10;
	double sugarGst = 2.5;
	public static void main(String[] args) throws Exception {
		RandomGenerator rg =new RandomGenerator();		
		String billNo="billNo1";
		double billRate=1905.00;
		rg.generateSalesEntry(1350,30,"2017-08-01",billNo,billRate);
	}


	public void generateSalesEntry(int sugarBags,int days,String start_dt_str,String billNo,double billRate) throws ParseException
	{
		ArrayList<ArrayList<Integer>> pattern_to_generate= generateBreakUpForSugar(sugarBags,days);
		System.out.println("Days for which patter generated "+pattern_to_generate.size());
		for (int i = 0; i < pattern_to_generate.size(); i++) {
			ArrayList<Integer> oneDayPattern = pattern_to_generate.get(i);
			Date start_dt;
			if(i==0)
			{
				start_dt = addDays(start_dt_str, 1, true);
			}
			else
			{
				start_dt = addDays(start_dt_str, 1, false);
			}
			for (int j = 0; j < oneDayPattern.size(); j++) {
				
				generateOrderAndOrderItem(oneDayPattern.get(j),start_dt,billNo,billRate,profitDecidedForSugar);				
				
			}
			
		}


	}


	public static Date addDays(String sourceDate, int days,boolean neglect) throws ParseException
	{
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		Date myDate = format.parse(sourceDate);
		if(neglect)
			return myDate;
		if(!timeSet)
		{
			timeSet=true;	
			cal.setTime(myDate);
		}
		cal.add(Calendar.DATE, days); //minus number would decrement the days
		return cal.getTime();
	}



	private void generateOrderAndOrderItem(Integer itemQty, Date start_dt,
			String billNo, double billRate,int profitDecidedForSugar){			
		PostRequestMain restUtil =new PostRequestMain ();
		Order order =restUtil.addOrder(prepareOrder(start_dt));
		restUtil.addOrderItem(prepareOrderitem(order.getOrder_id(),itemQty,billNo,billRate,profitDecidedForSugar));


	}
	private OrderItem prepareOrderitem(long ordId,Integer itemQty, String billNo, double billRate,
			int profitDecidedForSugar) {
		OrderItem ordItem=new OrderItem();
		ordItem.setBill_no_consumed(billNo);
		ordItem.setRate(billRate+profitDecidedForSugar);
		ordItem.setCgst_percentage(2.5);
		ordItem.setSgst_percentage(2.5);
		double gst_amt_per =((billRate+profitDecidedForSugar)*2.5)/100;
		double gst_amt_round_per =Math.round(gst_amt_per * 100) / 100;	
		
		double gst_amt =(itemQty*(billRate+profitDecidedForSugar)*2.5)/100;
		double gst_amt_round =Math.round(gst_amt * 100) / 100;	
		
		System.out.println("gst_amt "+gst_amt+"gst_amt_round "+gst_amt_round);
		ordItem.setCgst_amt(gst_amt_round);
		ordItem.setSgst_amt(gst_amt_round);
		ordItem.setHsbn_code("");
		ordItem.setCategory("SUGAR");
		ordItem.setItem_name("SUGAR");
		ordItem.setNet_rate(billRate+profitDecidedForSugar+gst_amt_round_per+gst_amt_round_per);
		ordItem.setOrder_total((ordItem.getRate()*itemQty)+gst_amt_round+gst_amt_round);
		ordItem.setOrder_qty(itemQty);
		ordItem.setOrder_unit("100KGS");
		ordItem.setOrder_id(ordId);	
		
		return ordItem;
	}
	private Order prepareOrder(Date billDt) {
		Order order=new Order();
		order.setCustomer_name("saravanan2");
		order.setOrder_date(billDt);
		return order;

	}
	public ArrayList<ArrayList<Integer>> generateBreakUpForSugar(int sugarBags,int days)
	{
		RandomGenerator rg =new RandomGenerator();		
		int perDayAvg =sugarBags/days;
		int minBillableSugarPerDay =perDayAvg-9;
		int maxBillableSugarPerDay =perDayAvg+9;
		int minItemPerBill =3;
		int maxItemPerBill =5;
		ArrayList<ArrayList<Integer>> month =new ArrayList<ArrayList<Integer>> ();
		ArrayList<Integer> loadList = rg.n_random(sugarBags,days,minBillableSugarPerDay,maxBillableSugarPerDay);
		for (int i = 0; i < loadList.size(); i++) {
			RandomGenerator rgin =new RandomGenerator();	    	
			int target =loadList.get(i)/5; ///number of bills for tat day  is decided as per tat day sales 
			month.add(rgin.simpleRandGenerator(loadList.get(i),target,minItemPerBill,maxItemPerBill));
		}
		System.out.println(month.size()); //moth contains number of bills per day(length of array indicates) and entry in each bill
		return month;

	}

	public ArrayList<Integer> simpleRandGenerator(int targetSum , int numberOfDraws,int min,int max)
	{
		Random r = new Random();
		ArrayList<Integer> load = new ArrayList<Integer>();		
		int sum = 0,i=0;
		while(targetSum>sum ) {
			i++;
			int next = r.nextInt(max + 1 - min) + min;
			if((sum+next)>=targetSum)
			{
				load.add(targetSum-sum);				
				break;
			}

			load.add(next); 
			sum+=next;

		}
		System.out.println("Random arraylist " + load);
		//System.out.println("Sum is "+ sum);
		return load;
	}



	public  ArrayList<Integer> n_random(int targetSum, int numberOfDraws,int min,int max) {
		Random r = new Random();
		ArrayList<Integer> load = new ArrayList<Integer>();


		int sum = 0;
		for (int i = 0; i < numberOfDraws; i++) {
			int next = r.nextInt(max + 1 - min) + min;
			load.add(next);
			sum += next;
		}

		//scale to the desired target sum
		double scale = 1d * targetSum / sum;
		sum = 0;
		for (int i = 0; i < numberOfDraws; i++) {
			load.set(i, (int) (load.get(i) * scale));
			sum += load.get(i);
		}

		//take rounding issues into account
		while(sum++ < targetSum) {	    	
			int i = r.nextInt(numberOfDraws);	      
			load.set(i, load.get(i) + 1);

		}

		System.out.println("Random arraylist " + load);
		System.out.println("Sum is "+ (sum - 1));
		return load;

	}



}
