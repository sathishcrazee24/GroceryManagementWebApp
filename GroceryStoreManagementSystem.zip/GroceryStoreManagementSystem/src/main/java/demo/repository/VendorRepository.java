package demo.repository;

import demo.model.Vendor;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

@RepositoryRestResource
public interface VendorRepository extends CrudRepository<Vendor, Long> {

}
