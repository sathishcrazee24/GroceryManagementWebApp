package demo.repository;
import demo.model.OrderItem;

import org.springframework.data.repository.CrudRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

@RepositoryRestResource
public interface OrderItemsRepository extends CrudRepository<OrderItem, Long> {

}
