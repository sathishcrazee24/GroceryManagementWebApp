package demo;

import java.io.File;

import com.fasterxml.jackson.databind.ObjectMapper;

import demo.model.Bill;
import demo.model.Customer;
import demo.model.Item;
import demo.model.Order;

import demo.model.Vendor;

public class JsonGenerator {

	public static void main(String[] args) throws Exception {
		ObjectMapper mapper = new ObjectMapper();
		
		//Object to JSON in file
		//mapper.writeValue(new File("c:\\user.json"), user);
		
		
		Item item = new Item();		
		String itemJson = mapper.writeValueAsString(item);
		System.out.println("Item :" +itemJson);
		System.out.println("");
		
		
		Bill bill = new Bill();		
		String billJson = mapper.writeValueAsString(bill);
		System.out.println("Bill :" +billJson);	
		System.out.println("");
		
		Customer customer = new Customer();		
		String customerJson = mapper.writeValueAsString(customer);
		System.out.println("Customer :" +customerJson);		
		System.out.println("");
		
		
		Order order = new Order();		
		String orderJson = mapper.writeValueAsString(order);
		System.out.println("Order :" +orderJson);		
		System.out.println("");
		
		
	/*	OrderItems orderItems = new OrderItems();		
		String orderItemsJson = mapper.writeValueAsString(orderItems);
		System.out.println("OrderItems :" +orderItemsJson);
		System.out.println("");*/
		
		
		Vendor vendor = new Vendor();		
		String vendorJson = mapper.writeValueAsString(vendor);
		System.out.println("Vendor :" +vendorJson);		
	}
}